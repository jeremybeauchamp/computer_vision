lineDetection module
====================

.. automodule:: lineDetection
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
