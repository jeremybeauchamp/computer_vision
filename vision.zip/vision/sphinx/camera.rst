Camera module
=============

.. automodule:: camera
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
