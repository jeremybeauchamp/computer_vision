Adding New Modules
==================

To add a new detection algorithm into the system, there are a few simple steps.

First, if you are adding detection for an object that has not yet been defined,
go to objects.py and make a object class with the parameters that you need as well 
as a conversion function. Follow the objects already in the file as a guidline.
Once that has been added, you'll move over to machineVision.py where most of the
changed will be made.

Add you new object to the object set called 'allObjects'. It will be found near
the top of the file.

Then you'll want to declare any variables you need in the __init__ function. If
your algorithm uses a class you'd want to declare that here. While you're in the
__init__ function, add one to the variable 'maxTasks' and make sure the variable
'taskList' has the same number of elements (all 0's) as 'maxTasks' indicates.

Then add your setup functions to the 'initialize' function.

Then create a new function within machineVision.py that simply calls your detection
function and using the output of that function updates the event.

After this function is created add a new branch of the if else statement in the
'assignJob' function that simply calls the new function you made.

All of these have comment blocks to show where exactly in the file these additions
or changes should be made as well as an example.

If you are simply replacing an existing module you just have to replace the old
declaration(in __init__ function) and setup function(in 'initialize' function) and
change the existing function that calls the actual detection function for the module
being replaced.
