Machine Vision module
=====================

.. automodule:: machineVision
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
