stabilizer module
=================

.. automodule:: stabilizer
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
