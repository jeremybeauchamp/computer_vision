CamBodyConversion module
========================

.. automodule:: CamBodyConversion
    :members:
    :undoc-members:
    :show-inheritance:
