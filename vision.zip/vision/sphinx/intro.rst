Introduction
============

This is the manual for the Machine Vision System for the PAVE Autonomous Vehicle.
The goal of this software is to efficiently and accurately detect lines, traffic lights,
obstacles, and other objects of interest and compile them into a single string that
will be passed to the next subsystem of the vehicle, the Cognitive State Machine.

The system was designed from the ground up with readability, modularity, and future
improvement in mind. The hope is that this project can continue to be used in the
future not only for competitions, but as a learning tool as well.

This manual covers all of the dependencies required to run the project, all of the
code (what each function does, what each variable represents, etc.) and how to add
new modules to the system
