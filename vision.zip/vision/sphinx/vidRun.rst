vidRun module
=============

.. automodule:: vidRun
    :members:
    :undoc-members:
    :show-inheritance:
