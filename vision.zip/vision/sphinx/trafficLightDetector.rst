Traffic Light Detector module
=============================

.. automodule:: trafficLightDetector
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
