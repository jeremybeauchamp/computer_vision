Dependencies
============

This project is written entirely in Python 3. The project relies on the folllowing 
libraries:
	-Tkinter
	-TensorFlow
	-OpenCV
	-Matplotlib
	-Scipy
	-Numpy
	-Pillow
	
All of these packages can be installed via pip3 aside from Tkinter, which can be
installed using your apt on Linux.
