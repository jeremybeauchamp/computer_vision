Objects module
==============

.. automodule:: objects
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
