utils package
=============

Submodules
----------

utils.category\_util module
---------------------------

.. automodule:: utils.category_util
    :members:
    :undoc-members:
    :show-inheritance:

utils.category\_util\_test module
---------------------------------

.. automodule:: utils.category_util_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.config\_util module
-------------------------

.. automodule:: utils.config_util
    :members:
    :undoc-members:
    :show-inheritance:

utils.config\_util\_test module
-------------------------------

.. automodule:: utils.config_util_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.dataset\_util module
--------------------------

.. automodule:: utils.dataset_util
    :members:
    :undoc-members:
    :show-inheritance:

utils.dataset\_util\_test module
--------------------------------

.. automodule:: utils.dataset_util_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.label\_map\_util module
-----------------------------

.. automodule:: utils.label_map_util
    :members:
    :undoc-members:
    :show-inheritance:

utils.label\_map\_util\_test module
-----------------------------------

.. automodule:: utils.label_map_util_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.learning\_schedules module
--------------------------------

.. automodule:: utils.learning_schedules
    :members:
    :undoc-members:
    :show-inheritance:

utils.learning\_schedules\_test module
--------------------------------------

.. automodule:: utils.learning_schedules_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.metrics module
--------------------

.. automodule:: utils.metrics
    :members:
    :undoc-members:
    :show-inheritance:

utils.metrics\_test module
--------------------------

.. automodule:: utils.metrics_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.np\_box\_list module
--------------------------

.. automodule:: utils.np_box_list
    :members:
    :undoc-members:
    :show-inheritance:

utils.np\_box\_list\_ops module
-------------------------------

.. automodule:: utils.np_box_list_ops
    :members:
    :undoc-members:
    :show-inheritance:

utils.np\_box\_list\_ops\_test module
-------------------------------------

.. automodule:: utils.np_box_list_ops_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.np\_box\_list\_test module
--------------------------------

.. automodule:: utils.np_box_list_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.np\_box\_ops module
-------------------------

.. automodule:: utils.np_box_ops
    :members:
    :undoc-members:
    :show-inheritance:

utils.np\_box\_ops\_test module
-------------------------------

.. automodule:: utils.np_box_ops_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.object\_detection\_evaluation module
------------------------------------------

.. automodule:: utils.object_detection_evaluation
    :members:
    :undoc-members:
    :show-inheritance:

utils.object\_detection\_evaluation\_test module
------------------------------------------------

.. automodule:: utils.object_detection_evaluation_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.ops module
----------------

.. automodule:: utils.ops
    :members:
    :undoc-members:
    :show-inheritance:

utils.ops\_test module
----------------------

.. automodule:: utils.ops_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.per\_image\_evaluation module
-----------------------------------

.. automodule:: utils.per_image_evaluation
    :members:
    :undoc-members:
    :show-inheritance:

utils.per\_image\_evaluation\_test module
-----------------------------------------

.. automodule:: utils.per_image_evaluation_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.shape\_utils module
-------------------------

.. automodule:: utils.shape_utils
    :members:
    :undoc-members:
    :show-inheritance:

utils.shape\_utils\_test module
-------------------------------

.. automodule:: utils.shape_utils_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.static\_shape module
--------------------------

.. automodule:: utils.static_shape
    :members:
    :undoc-members:
    :show-inheritance:

utils.static\_shape\_test module
--------------------------------

.. automodule:: utils.static_shape_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.string\_int\_label\_map\_pb2 module
-----------------------------------------

.. automodule:: utils.string_int_label_map_pb2
    :members:
    :undoc-members:
    :show-inheritance:

utils.test\_utils module
------------------------

.. automodule:: utils.test_utils
    :members:
    :undoc-members:
    :show-inheritance:

utils.test\_utils\_test module
------------------------------

.. automodule:: utils.test_utils_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.variables\_helper module
------------------------------

.. automodule:: utils.variables_helper
    :members:
    :undoc-members:
    :show-inheritance:

utils.variables\_helper\_test module
------------------------------------

.. automodule:: utils.variables_helper_test
    :members:
    :undoc-members:
    :show-inheritance:

utils.visualization\_utils\(backup\) module
-------------------------------------------

.. automodule:: utils.visualization_utils(backup)
    :members:
    :undoc-members:
    :show-inheritance:

utils.visualization\_utils module
---------------------------------

.. automodule:: utils.visualization_utils
    :members:
    :undoc-members:
    :show-inheritance:

utils.visualization\_utils\_test module
---------------------------------------

.. automodule:: utils.visualization_utils_test
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: utils
    :members:
    :undoc-members:
    :show-inheritance:
