#!/bin/bash

cd sphinx
make clean

cd ../code
rm -rf __pycache__
