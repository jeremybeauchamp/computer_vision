#!/bin/bash
cd sphinx
make html
