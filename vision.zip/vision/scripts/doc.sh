#!/bin/bash

cd sphinx
make latex
cd _build/latex
make

cp AutonomousVehicleMachineVisionSystem.pdf ../../../Manual.pdf
