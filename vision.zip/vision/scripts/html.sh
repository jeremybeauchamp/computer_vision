#!/bin/bash
cd sphinx/_build/html
firefox index.html
