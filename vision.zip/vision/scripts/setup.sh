#!/bin/bash
sudo apt install python3-pip
sudo apt install python3-tk
pip3 install virtualenv
python3 -m virtualenv .vision
source .vision/bin/activate
cat scripts/freeze.txt | xargs pip3 install
