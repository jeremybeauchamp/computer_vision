#----------------------------------------------#
# Autonomous Vehicle Machine Vision System     #
# Machine Vision System                        #
# machineVision.py                             #
# Written by:                                  #
# Jeremy Beauchamp, Zhaojie Chen,              #
# Trenton Davis, and Xudong Yuan               # 
#----------------------------------------------#

'''
This file contains the overall Machine Vision System as well as any constants that
are necessary. All of the functionality of the whole system is contained in this 
single file. There are also guides as to what would need to be added/modified to
add new detection algorithms.
'''

# Import libraries
import time
import threading
import numpy as np
import cv2
from queue import Queue

# Import modules
import camera as c
import imageData as imd
import gui as g
import stabilizer as s
import enhancer as e
import objects as o
import mvevent as ev
import trafficLightDetector as tld
import yellowline_detection as yd
import lineDetection as ld
from yolo3.yolo import YOLO

## Cameras ##
# These are just camera constants for cameras that have known parameters
webcam = c.Camera(fps = 30, res = [640, 480], video = 0)	#Testing webcam
vehicle = c.Camera(fps = 60, res = [1280, 720], video = 0)	#Vehicle camera

## Object Sets ##
# Right now this is the only object set being used, in the future it may be helpful
# to remove unecessary objects for certain events. In which case a new object
# set could be added here
allObjects = [o.TrafficLight(), o.Lines(), o.FinishLine(), o.Obstacle(), o.Car(), o.Arrow()]

# These are the default settings for the vision system. These can be changed here
# or they can be changed when initally instantiating the class.
options = dict(camera = webcam,
			   objectSet = allObjects)
			   
video = dict(videoMode =True,
			 video = "straightline_raw.mp4",
			 camera = webcam,
			 objectSet = allObjects)
			 

green_count = 0

# MachineVision Class
################################################################################
class MachineVision:
	'''
	The MachineVision class is the overall class that contains the Autonomous
	Vehicle Machine Vision System. It is responsible for housing all detection
	algorithms, updating the event with the findings of these algorithms, and 
	sending this information to the cognitive state machine in a timely manor.
	:ivar camera: the camera used to capture images
	:ivar gui: the GUI that displays the images
	:ivar stabilizer: the video stabilizer
	:ivar enhancer: the image enhancer
	:ivar event: container for all of the data acquired by the vision system
	:ivar trafficLightNN: the neural network responsible for detecting the traffic light
	:ivar lineDetection: the class that has all of the line detection functions
	:ivar yolo: neural network that detects arrows
	
	:ivar LookoutRange: used for old version of yellow line detection...
	:ivar Region_WB: used for old version of yellow line detection...
	:ivar line_detec: instance of old yellow line detection
	
	:ivar videoMode: indicates if program is running on a test video or camera feed
	:ivar cap: used in place of camera in when videoMode is true
	
	:ivar current: the current image that is being analyzed
	:ivar previous: the previous image that was analyzed, used for stabilization
	
	:ivar BufferSize: the amount of images stored in the buffer
	:ivar ImageBuffer: the buffer storing images
	:ivar BufferIndex: the current index in the buffer
	
	:ivar printLock: a lock preventing threads from printing at the same time
	:ivar frameLock: a lock preventing threads from modifying the frame at same time
	:ivar q: queue that is used to launch threads
	:ivar tasks: number of current tasks running
	:ivar taskList: list of tasks running, used for launching threads
	:ivar threads: list of threads to launch
	:ivar maxTasks: maximum number of tasks
	:ivar color: the color to be detected with line detection
	'''

	def __init__(self, videoMode = False, video = None, camera = c.Camera(), objectSet = []):
		'''
		Creates all variables needed for the program to run.
		:type videoMode: bool
		:param videoMode: if the program will be run on a video rather than camera stream
		:type video: string with path to a video to be used
		:param video: the video to run the program on
		:type camera: Camera object
		:param camera: the camera used for capturing images
		:type objectSet: a list of objects
		:param objectSet: all of the objects that will need to be detected
		'''
		
		# |  |
		#_|  |_  If you are adding a new module, declare it here!
		#\    /  ################################################
		# \  /
		#  \/
		#self.moduleName = filename.ModuleName()
		self.gui = g.GUI()
		self.stabilizer = s.Stabilizer()
		self.enhancer = e.Enhancer()
		self.event = ev.MVEvent(objectSet)
		self.trafficLightNN = tld.TrafficLightDetector()
		self.lineDetection = ld.LineDetection()
		self.yolo = YOLO()
		
		#For yellow line detection
		LookoutRange = [1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5.5, 6.5, 7.5]
		Region_WB = [250, 270, 360, 380]
		self.line_detec = yd.yellowline(camera, LookoutRange, Region_WB)

		#Setting variables based on whether or not video mode is on
		if videoMode and (video is not None):
			self.videoMode = True
			self.cap = cv2.VideoCapture(video)
			self.camera = [0]
			self.enhancer.x = 640
			self.enhancer.y = 480
		else:
			self.videoMode = False
			self.camera = [camera]

		#Initialize the image variables
		self.current = 0
		self.previous = imd.ImageData(0)
		
		#Initialize buffer variables
		self.BufferSize = 0
		self.ImageBuffer = []
		self.BufferIndex = 0
		
		#Setup for threading
		self.printLock = threading.Lock()
		self.frameLock = threading.Lock()
		self.q = Queue()
		self.tasks = 0
		self.taskList = []
		
		# |  |
		#_|  |_  If a new module is added, add a 0 to this list and add one to maxTasks!
		#\    /  #######################################################################
		# \  /   ex. self.threads = [0, 0, 0, 0, 0, 0]
		#  \/        self.maxTasks = 6
		self.threads = [0, 0, 0, 0]
		self.maxTasks = 4
		
		#Variable for the color of
		self.color = np.array([0, 0, 0])
		
		#Bools indicating whether or not the associated task should display it overlay
		self.lineOverlay = True
		self.trafficLightOverlay = True
		self.finishOverlay = True
		self.arrowOverlay = True

	def initialize(self):
		'''
		Creates image buffer and activates the camera and GUI.
		'''
		
		#Setup for enhancer, gui, camera, and buffer based on whether or not video mode is on
		#The initial image is also set here
		if(not self.videoMode):
			self.enhancer.setSize(self.camera[0].RES[0], self.camera[0].RES[1])
			self.gui.activate(self.camera[0].RES[0], self.camera[0].RES[1])
			self.camera[0].activate()
			self.BufferSize = self.camera[0].FPS
			self.current = imd.ImageData(self.camera[0].capture())
		else:
			self.enhancer.setSize(640, 480)
			self.gui.activate(640, 480)
			self.BufferSize = 10
			for i in range(5):
				_, image = self.cap.read()
			self.current = imd.ImageData(image)
      
      	#Fill buffer with dummy images
		for i in range (self.BufferSize):
			self.ImageBuffer.append(imd.ImageData(0))
			
		#Set amount of frames until stabilizer resets rolling average
		self.stabilizer.smoothingWindow = self.BufferSize

		#Activate trafficLight detector
		self.trafficLightNN.activate()
		
		# |  |
		#_|  |_  If you add any new modules, place any setup functions here
		#\    /  ##########################################################
		# \  /
		#  \/
		#self.newModule.activate()
		
		#Sets color of lines to be detected
		cv2.imshow('White line', self.current.frame)
		cv2.setMouseCallback("White line", self.getposBgr)
		cv2.waitKey(0)
		print("The Bgr for line is:", self.color)
		#Set color for line
		self.lineDetection.lowerLine[:] = self.color[:] - 25
		self.lineDetection.upperLine[:] = self.color[:] + 25
		cv2.destroyAllWindows()
		cv2.imshow('Finish line', self.current.frame)
		cv2.setMouseCallback("Finish line", self.getposBgr)
		cv2.waitKey(0)
		print("The Bgr for finish line is:", self.color)
		#Set color for finish line
		self.lineDetection.lowerfinish[:] = self.color[:] - 25
		self.lineDetection.upperfinish[:] = self.color[:] + 25
		cv2.destroyAllWindows()
		cv2.imshow('Orange cone', self.current.frame)
		cv2.setMouseCallback("Orange cone", self.getposBgr)
		cv2.waitKey(0)
		print("The Bgr for orange cone is:", self.color)
		#Set color for orange cone
		self.lineDetection.lowerorange[:] = self.color[:] - 25
		self.lineDetection.upperorange[:] = self.color[:] + 25
		cv2.destroyAllWindows()

	def shutdown(self):
		'''
		Shutsdown the camera and GUI.
		'''

		if not self.videoMode:
			for c in self.camera:
				c.deactivate()

		if(self.gui.active):
			self.gui.deactivate()
			
		cv2.destroyAllWindows()
		
	#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	# The ability to use multiple cameras is NOT complete. We just wanted to provide
	# a way to add cameras for the future
	#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	def addCamera(self, newCamera):
		'''
		Allows the addition of multiple cameras.
		
		:type newCamera: Camera object
		:param newCamera: the camera to be added to the list
		'''
		
		self.camera.append(newCamera)
		
	# These are unimplemented call back functions for the GUI to turn these overlays
	# on or off!
	def setLineOverlay(self, option):
		'''
		Turn overlay on/off
		
		:type option: bool
		:param option: True = on, False = ff
		'''
		
		self.lineOverlay = option
	
	def setTrafficLightOverlay(self, option):
		'''
		Turn overlay on/off
		
		:type option: bool
		:param option: True = on, False = ff
		'''
		
		self.trafficLightOverlay = option
		
	def setFinishOverlay(self, option):
		'''
		Turn overlay on/off
		
		:type option: bool
		:param option: True = on, False = ff
		'''
		
		self.finishOverlay = option
		
	def setArrowOverlay(self, option):
		'''
		Turn overlay on/off
		
		:type option: bool
		:param option: True = on, False = ff
		'''
		
		self.arrowOverlay = option
			
	def detectTrafficLight(self):
		'''
		Detects if there is a traffic light present. Calls the detect function of 
		trafficLightNN and adds an overlay to the image if it is turned on.
		'''
		res1, res2, boxes = self.trafficLightNN.detect(self.current)
		self.event.objects[0].active = res1
		self.event.objects[0].green = res2
		
		im_width= self.current.frame.shape[1]
		im_height = self.current.frame.shape[0]
		ymin, xmin, ymax, xmax = boxes[0][0].tolist()
		left, right, top, bottom = map(lambda x:int(x),[xmin * im_width, xmax * im_width,ymin * im_height, ymax * im_height])
		box = [left, right, top, bottom]
		
		if self.trafficLightOverlay:
			self.frameLock.acquire()
			try:
				cv2.rectangle(self.current.frame, (box[0], box[2]), (box[1], box[3]), (0, 128, 255), 2)
			finally:
				self.frameLock.release()
			
	def detectLines(self):
		'''
		Detects if there are lines of the designated color in the frame by calling
		the lines function of lineDetection and adds an overlay if turned on.
		'''
		# as graduate students' requirement, we can use function to express the line here
		# two points and four coordinates and the slope
		left, right, leftTurn, rightTurn, lines, slope = self.lineDetection.lines(self.current.frame)
		self.event.objects[1].active = (left or right)
		self.event.objects[1].leftLine = left
		self.event.objects[1].rightLine = right
		self.event.objects[1].turning = (leftTurn or rightTurn)
		self.event.objects[1].turnLeft = (leftTurn and (not rigthTurn))
		self.event.objects[1].turnRight = (rightTurn and (not leftTurn))
		self.event.objects[1].slope = slope
	
		if self.lineOverlay:
			self.frameLock.acquire()
			try:
				if lines is None:
					pass
				else:
					for line in lines:
						self.event.objects[1].active = True
						for x1, y1, x2, y2 in line:
							cv2.line(self.current.frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
							if x1 < (self.enhancer.x/2):
								self.event.objects[1].leftLine = True
							elif x1 > (self.enhancer.x/2):
								self.event.objects[1].rightLine = True
			finally:
				self.frameLock.release()
			
	def detectFinishLine(self):
		'''
		Detects if there are finish line on the screen.
		'''
		active, lines = self.lineDetection.finishLines(self.current.frame)
		self.event.objects[2].active = active
		
		if self.finishOverlay:
			self.frameLock.acquire()
			try:
				if lines is None:
					pass
				else:
					for line in lines:
						self.event.objects[1].active = True
						for x1, y1, x2, y2 in line:
							cv2.line(self.current.frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
			finally:
				self.frameLock.release()

	def detectImage(self):
		'''
		Detects arrows within an image, and updates the event with the information found.
		'''
		self.current.frame, temp = self.yolo.detect_image(self.current.frame,"no boxes")
		if len(temp) > 0:
			thickness = (self.current.frame.shape[0] + self.current.frame.shape[1]) // 400
			best = max(temp, key = itemgetter(1))
			label = '{} {:.2f}'.format(best[0], best[1])
			box = best[2]

			if best[0] == "arrow up":
				self.event.objects[5].active = True
				self.event.objects[5].upArrow = True
				self.event.objects[5].leftArrow = False
				self.event.objects[5].rightArrow = False
			elif best[0] == "arrow left":
				self.event.objects[5].active = True
				self.event.objects[5].leftArrow = True
				self.event.objects[5].upArrow = False
				self.event.objects[5].rightArrow = False
			elif best[0] == "arrow right":
				self.event.objects[5].active = True
				self.event.objects[5].rightArrow = True
				self.event.objects[5].upArrow = False
				self.event.objects[5].leftArrow = False
			else:
				self.event.objects[5].active = False
				self.event.objects[5].upArrow = False
				self.event.objects[5].rightArrow = False
				self.event.objects[5].leftArrow = False
		else:
			self.event.objects[5].active = False
			self.event.objects[5].upArrow = False
			self.event.objects[5].rightArrow = False
			self.event.objects[5].leftArrow = False
			
			if self.arrowOverlay:
				self.frameLock.acquire()
				try:
					top, left, bottom, right = box
					top = max(0, np.floor(top + 0.5).astype('int32'))
					left = max(0, np.floor(left + 0.5).astype('int32'))
					bottom = min(self.current.frame.shape[1], np.floor(bottom + 0.5).astype('int32'))
					right = min(self.current.frame.shape[0], np.floor(right + 0.5).astype('int32'))

					cv2.rectangle(self.current.frame, (left,top), (right,bottom) ,(0,255,0) ,thickness)
					cv2.putText(self.current.frame, label, (left,top), cv2.FONT_HERSHEY_DUPLEX,1,(0,255,0),1, cv2.LINE_AA)
				finally:
					self.frameLock.release()
			
	# |  |
	#_|  |_  If a new module is added, make a new function here that does all of 
	#\    /  the things you new module needs to run!
	# \  /   ###################################################################
	#  \/
	#def newFunction(self):
	#	self.newModule.detect(self.current.image)
	
				
	def assignJob(self):
		'''
		Assigns jobs for the multithreading to work.
		'''
		#Launched at the creation of each thread, determines which threads to run
		i = self.q.get()
		if(i == 0):
			self.detectTrafficLight()
		elif(i == 1):
			self.detectLines()
		elif(i == 2):
			self.detectFinishLine()
		# |  |
		#_|  |_  If a new module is added, add another elif that calls your new funtion!
		#\    /  #######################################################################
		# \  /
		#  \/
		#elif(i == 3):
		#	self.newFunction()
		self.q.task_done()
		
	def turnOnTask(self, number):
		'''
		Turns on the specified task.
		
		:type number: int
		:param number: the number of the task to turn on
		'''
		
		if(number not in self.taskList):
			self.taskList.append(number)
			self.tasks = self.tasks + 1
		
	def turnOffTask(self, number):
		'''
		Turns off the specified task.
		
		:type number: int
		:param number: the number of the task to turn off
		'''
		if(number in self.taskList):
			self.taskList.remove(number)
			self.tasks = self.tasks - 1

	def getposBgr(self, event, x, y, flags, param):		
		if event==cv2.EVENT_LBUTTONDOWN:
			self.color = self.current.frame[y, x]
			print("The Clicking Bgr is:", self.color)
			
	def fillQueue(self):
		for t in self.taskList:
			self.q.put(t)
			
	def setTasks(self, currentTasks):
		'''
		Takes the input from the state machine and converts it into a queue of
		tasks.
		
		:type currentTasks: string of 0's and 1's
		:param currentTasks: input from the state machine
		'''
		
		if(len(currentTasks) > self.maxTasks):
			currentTasks = currentTasks[:self.maxTasks - 1]
		elif(len(currentTasks) < self.maxTasks):
			for i in range(self.maxTasks - len(currentTasks)):
				currentTasks += '0'
		current = 0
		for c in currentTasks:
			if(c == '1'):
				self.turnOnTask(current)
			else:
				self.turnOffTask(current)
			current = current + 1
		self.fillQueue()

	def oneLoop(self, currentTasks):
		'''
		Executes one loop of the machine vision system.
		
		:type currentTasks: string of 0's and 1's
		:param currentTasks: the input from the state machine on which tasks to run
		'''

		global green_count
		
		#Obtains new image
		if self.videoMode:
			_, image = self.cap.read()
			self.current = imd.ImageData(image)
		else:
			self.current = imd.ImageData(self.camera[0].capture())

		#Runs image through pre-processing
		self.current.frame = self.enhancer.enhance(self.current)
				
		#Stabilizer would go here, but it is not currently working
		
		#Decide which threads to launch
		self.setTasks(currentTasks)
		for i in range (self.tasks):
			self.threads[i] = threading.Thread(target = self.assignJob)
			self.threads[i].daemon = True
			self.threads[i].start()
		for i in range(self.tasks):
			self.threads[i].join()
			
		#Run Arrow detection on image
		if(4 in self.taskList):
			self.detectImage()
			
		#Updates image buffer
		self.ImageBuffer[self.BufferIndex] = self.current
		self.BufferIndex = self.BufferIndex + 1
		if(self.BufferIndex >= self.BufferSize):
			self.BufferIndex = 0
				
		#Checks amount of consecutive frames that a green light has been detected
		#in order to reduce false positives
		if self.event.objects[0].active == True:
			if self.event.objects[0].green == True:
				if green_count >= 3:
					self.event.objects[0].green = True
					green_count += 1
				else:
					self.event.objects[0].green = False
					green_count += 1
			elif self.event.objects[0].green == False:
				green_count = 0
		elif self.event.objects[0].active == False:
			green_count = 0

		#Return image and event string for the state machine
		return self.current, self.event.convert()

################################################################################