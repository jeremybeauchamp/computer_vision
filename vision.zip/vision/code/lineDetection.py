#----------------------------------------------#
# Autonomous Vehicle Machine Vision System     #
# Machine Vision System                        #
# lineDetection.py                             #
# Written by:                                  #
# Jeremy Beauchamp, Zhaojie Chen,              #
# Trenton Davis, and Xudong Yuan               # 
#----------------------------------------------#

'''
This file contains if there is line detection and where it is.
'''

import cv2
import numpy as np

# LineDetection class
################################################################################
class LineDetection:
	'''
	The LineDetection class is the class we implemented to detect lines from the image.
	'''
	def __init__(self):
		'''
		Initializes the line detection.
		'''
		
		self.lowerLine = np.array([0, 200, 200])
		self.upperLine = np.array([215, 255, 255])
		self.lowerfinish = np.array([0, 150, 0])
		self.upperfinish = np.array([255, 255, 255])
		self.lowerorange = np.array([0, 150, 0])
		self.upperorange = np.array([255, 255, 255])
		self.kernel = np.ones((5, 5), np.uint8)
		
	def convertToHSV(self, frame):
		'''
		Formats the array of pixels to be in HSV format.
		'''
		return cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
		
	def convertToHLS(self, frame):
		'''
		Formats the array of pixels to be in HLS format.
		'''
		return cv2.cvtColor(frame, cv2.COLOR_BGR2HLS)
		
	def lines(self, frame):
		'''
		Detects lines of the specified color and their location
		
		:type frame: image
		:param frame: the image to analyze
		'''
		hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
		mask = cv2.inRange(frame, self.lowerLine, self.upperLine)
		res = cv2.bitwise_and(frame, frame, mask = mask)
		res  = cv2.GaussianBlur(res, (15, 15), 0)
		res = cv2.cvtColor(res, cv2.COLOR_HSV2BGR)
		res = cv2.cvtColor(res, cv2.COLOR_BGR2GRAY)
		edges = cv2.Canny(res, 50, 100)
		lines = cv2.HoughLinesP(edges, 1, np.pi/180, 60, 50, 10)
		
		topLeft = []
		topRight = []
		bottomLeft = []
		bottomRight = []
		if lines is None:
			pass
		else:
			for line in lines:
				'''
				Use coordinates to indicate the position of the point(x1,y1),(x2,y2)
				'''
				for x1, y1, x2, y2 in line:
					if x1 < 320 and y1 < 240:
						topLeft.append(line)
					elif x1 >= 320 and y1 < 240:
						topRight.append(line)
					elif x1 < 320 and y1 >= 240:
						bottomLeft.append(line)
					else:
						bottomRight.append(line)
						
		l = [topLeft, topRight, bottomLeft, bottomRight]
		# original value
		slope = [0.0, 0.0, 0.0, 0.0]
		distance = [0, 0, 0, 0]
		count = [0, 0, 0, 0]
		left = False
		right = False
		for i in range(len(l)):
			yMax = 0
			yMin = 1000
			for line in l[i]:
				count[i] += 1
				s = 0
				for x1, y1, x2, y2 in line:
					# get the slope of the line
					s = (y2 - y1) / (x2 - x1)
					if y1 > yMax:
						yMax = y1
					if y2 > yMax:
						yMax = y2
					if y1 < yMin:
						yMin = y1
					if y2 < yMin:
						yMin = y2
				slope[i] += s
			distance[i] = yMax - yMin
			if distance[i] > 0:
				slope[i] /= count[i]
		if distance[0] + distance[2] >= 200:
			left = True
		else:
			left = False
		if distance[1] + distance[3] >= 200:
			right = True
		else:
			right = False
		'''
		We do a tangent to each point on the line to 
		determine whether to go straight or turn
		'''	
		if left and slope[0] >= 0.0 and slope[2] < 0.0:
			leftTurn = True
		elif right and slope[1] < slope[3] / 2:
			leftTurn = True
		else:
			leftTurn = False
		if right and slope[1] <= 0.0 and slope[3] > 0.0:
			rightTurn = True
		elif left and slope[0] > slope[2] / 2:
			rightTurn = True
		else:
			rightTurn = False
		'''
		return the value, so we can use on machinevision.py
		'''
		return left, right, leftTurn, rightTurn, lines, slope

	def finishLines(self, frame):
		'''
		Will detect the final line, and its position.
		'''
		src = frame
		'''
		Convert image to grayscale image
		'''
		hls = cv2.cvtColor(src, cv2.COLOR_BGR2HLS)
		mask = cv2.inRange(hls, self.lowerfinish, self.upperfinish)
		res = cv2.bitwise_and(src, src, mask = mask)
		gray_src = cv2.cvtColor(res, cv2.COLOR_BGR2GRAY)
		gray_src = cv2.bitwise_not(gray_src)
		binary_src = cv2.adaptiveThreshold(gray_src, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 15, -2)
		'''
		Set the slope of the horizontal line
		'''
		hline = cv2.getStructuringElement(cv2.MORPH_RECT, ((binary_src.shape[1] // 10), 1), (-1, -1))
		'''
		Set the slope of the vertical line
		'''
		vline = cv2.getStructuringElement(cv2.MORPH_RECT, (1, (binary_src.shape[0] // 16)), (-1, -1))
		'''
		Expand and erode horizontal lines so that 
		there are only horizontal lines in the picture
		'''
		dst = cv2.morphologyEx(binary_src, cv2.MORPH_OPEN, hline)
		dst = cv2.bitwise_not(dst)
		count = 0
		fd = False
		edges = cv2.Canny(dst,50,150,apertureSize = 3)
		lines = cv2.HoughLinesP(edges,1,np.pi/180,30,minLineLength=75,maxLineGap=10)
		size = frame.shape
		if lines is None:
			fd = False
		elif (lines.any() != None):
			lines1 = lines[:,0,:]
			for x1,y1,x2,y2 in lines1[:]:
				if y1 > 100 and y1 < size[1] - 100 :
					count = count + 1
		if count > 2:
			fd = True
		'''
		return the value whether there is a finish line and the 
		value of the finish line, so we can use on machinevision.py
		'''
		return fd, lines
