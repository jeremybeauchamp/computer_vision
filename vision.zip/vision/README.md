#  TBD2
## Team Best Developers 2
* Team Members
    * Team Leader: Jeremy Beauchamp
	* Documentation Manager: Trenton Davis
	* Release Manager: Zhaojie Chen
	* Quality Assurance: XudongYuan
* Project Information
	* Project: Autonomous Vehicle Vision System
	* Client: Dr.Zhu
	* Description: This project will be able to detect and process various important visual information that is detected by the vehicles camera.

### Requirements
* Tools
	* python3
	* Sphinx
	* Tkinter
	* OpenCV
	* Pillow
	* Tensorflow
	* numpy
	* scipy
	* matplotlib
	
All of these tools aside from Tkinter can be install with pip.

### Scripts
There are a few scripts that we wrote to make some things easier. These must all 
be called from the main directory to have the desired effect. For example, to call
the setup script, you would type "scripts/setup.sh" from the main directory.

* Scripts
	* setup.sh - installs all dependencies and creates a virtual python environment called .vision
	* doc.sh - creates latex documentation and builds the pdf manual
	* docHTML.sh - creats HTML documentation.
	* html.sh - opens the HTML documentation in firefox.
	* clean.sh - deletes all documentation and __pycache__

A few important things to note, the setup.sh script will create a virtual environment
in your directory that is called .vision. To activate it you will have to type source .vision/bin/activate.
Since you have to do this everytime you want to run the program, I suggest adding an alias in your .bashrc file.
ex. alias vision="source ~/tbd2/.vision/bin/activate" at the bottom of .bashrc. It is also important to know that
the doc.sh script requires two additional packages to build the pdf manual. You
will have to install latexmk and texlive-formats-extra. Also, to use doc.sh or docHTML.sh, you will need your
python environment activate.
